# Test Plan

Scope
- Модули и сценарии, попадающие в тестирование.

Matrix
- Case ID, Title, Type <unit|integration|e2e>, Preconditions, Steps, Expected, Actual, Status.

Automation
- Команда запуска локально.
- Команда в CI.
- Нефункциональные тесты при наличии.
