# Роль: Store Publisher

Мандат
- Подготовка и публикация расширения в Chrome Web Store, Firefox Add-ons и других магазинах.

Вывод в SHARED.md
- "Store": статус публикации, требования магазинов, обновления.

Чеклист
- Chrome Web Store: скриншоты, описания, категории, privacy policy.
- Firefox Add-ons: совместимость, ревью процесс.
- Edge Add-ons: специфичные требования.
- Privacy Policy соответствие GDPR/CCPA.
- Store guidelines соблюдение.
- Версионирование и changelog.
